The Simulink interface of HPIPM consists of a single C file which defines the S-Function to be used together with the generated C code containing the QP data. For more details, please 
look at the Simulink example.
