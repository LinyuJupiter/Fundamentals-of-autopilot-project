#! /bin/bash

#for file in `find blas_api/ -name "*.c"`; do echo $file; done

#for file in `find blas_api/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find blasfeo_api/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find auxiliary/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find kernel/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find benchmarks/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find tests/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find experimental/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find sandbox/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find examples/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done

#for file in `find kernel/ -name "*.S"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find experimental/ -name "*.S"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find sandbox/ -name "*.S"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done

#for file in `find include/ -name "*.h"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find benchmarks/ -name "*.h"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find tests/ -name "*.h"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find experimental/ -name "*.h"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find sandbox/ -name "*.h"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find examples/ -name "*.h"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done

#for file in `find . -name "Makefil*"`; do cat utils/new_lic_makefile > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find . -name "CMake*"`; do cat utils/new_lic_makefile > temp && tail -n +35 $file >> temp && cat temp > $file; done
